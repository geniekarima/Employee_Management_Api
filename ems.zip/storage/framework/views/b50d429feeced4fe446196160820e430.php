<?php
    $msg = '';
    if (!empty($fromDate) && !empty($toDate)) {
        $msg = 'Report List from ' . $fromDate . ' to ' . $toDate;
    } elseif (!empty($fromDate)) {
        $msg = 'Report List from:- ' . $fromDate;
    } else {
        $msg = 'Report List for:-' . $toDate;
    }
?>

<!DOCTYPE html>
<html>

<head>
    <title>Monthly Employee Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #336699;
            margin-top: 20px;
        }

        p {
            text-align: center;
            color: #777;
            margin-top: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
        }

        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tbody tr:hover {
            background-color: #473030;
        }
    </style>
</head>

<body>
    <h1>
        <?php if(!empty($username)): ?>
            <?php echo e($username); ?> 's
        <?php else: ?>
            All Employees
        <?php endif; ?> Monthly Report List
    </h1>
    <p> <?php echo e($msg); ?></p>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Employee</th>
                <th>CheckIn</th>
                <th>CheckOut</th>
                <th>Working Hours</th>
                <th>Total Hours</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($report->date); ?></td>
                    <td><?php echo e($report->user->username); ?></td>
                    <td><?php echo e(\App\Traits\Base::timeParse($report->check_in)); ?></td>
                    <td><?php echo e(\App\Traits\Base::timeParse($report->check_out)); ?></td>

                    <td>
                        <?php if(!empty($report->net_work_hours)): ?>
                            <?php echo e($report->net_work_hours); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!empty($report->check_in) && !empty($report->check_out)): ?>
                            <?php
                                $total_duration = \App\Traits\Base::convertDateTime($report->check_in, $report->check_out);
                            ?>
                            <?php echo e($total_duration); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($report->breakTasks != null): ?>
                    <?php $__currentLoopData = $report->breakTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br_report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($report->user->username); ?> Break time</td>
                            <td><?php echo e($report->user->username); ?></td>
                            <td>
                                <?php if(!empty($br_report->break_start)): ?>
                                    <?php echo e(\App\Traits\Base::timeParse($br_report->break_start)); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!empty($br_report->break_end)): ?>
                                    <?php echo e(\App\Traits\Base::timeParse($br_report->break_end)); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!empty($br_report->break_start) && !empty($br_report->break_end)): ?>
                                    <?php
                                        $duration = \App\Traits\Base::convertDateTime($br_report->break_start, $br_report->break_end);
                                    ?>
                                    <?php echo e($duration); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
</body>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\employee_management_api\resources\views/employee_report.blade.php ENDPATH**/ ?>